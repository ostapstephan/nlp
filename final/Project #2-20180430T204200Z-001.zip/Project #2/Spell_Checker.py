from tkinter import Tk, scrolledtext, Menu, filedialog, END, messagebox
import os
import nltk

class Spell_Checker:

    def __init__(self, dictionary):
        self.old_text_word_list = ([])

        self.dictionary = {}

        #Fill dict with old dictionary
        with open(dictionary, 'r') as f:
            for line in f:
                word = line.split()[0]
                self.dictionary[word] = int(line.split()[1])

    def new_words(self, current_text):
        current_text_word_list = ([])

        for sentence in nltk.sent_tokenize(current_text):
            for word in nltk.word_tokenize(sentence):
                if word not in current_text_word_list:
                    current_text_word_list.append(word)

        new_words = [i for i in current_text_word_list if i not in self.old_text_word_list]

        self.old_text_word_list = current_text_word_list
        print(new_words)

        return new_words


    def spell_check(self, current_text):

        new_words = self.new_words(current_text)

        return new_words
